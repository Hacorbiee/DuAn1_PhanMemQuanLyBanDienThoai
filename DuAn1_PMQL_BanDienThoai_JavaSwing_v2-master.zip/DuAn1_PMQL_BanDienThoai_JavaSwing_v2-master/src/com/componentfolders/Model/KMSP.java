/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.componentfolders.Model;

/**
 *
 * @author HA NGUYEN
 */
public class KMSP {
    int IDSP, IDHang,IDKM;
    String TenSP;

    public int getIDKM() {
        return IDKM;
    }

    public void setIDKM(int IDKM) {
        this.IDKM = IDKM;
    }

    public KMSP() {
    }

    public int getIDSP() {
        return IDSP;
    }

    public void setIDSP(int IDSP) {
        this.IDSP = IDSP;
    }

    public int getIDHang() {
        return IDHang;
    }

    public void setIDHang(int IDHang) {
        this.IDHang = IDHang;
    }

    public String getTenSP() {
        return TenSP;
    }

    public void setTenSP(String TenSP) {
        this.TenSP = TenSP;
    }

   
    
}
