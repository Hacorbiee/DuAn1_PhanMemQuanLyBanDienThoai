package com.raven.event;

import java.awt.Component;

public interface EventShowPopupMenu {

    public void showPopup(Component com);
}
