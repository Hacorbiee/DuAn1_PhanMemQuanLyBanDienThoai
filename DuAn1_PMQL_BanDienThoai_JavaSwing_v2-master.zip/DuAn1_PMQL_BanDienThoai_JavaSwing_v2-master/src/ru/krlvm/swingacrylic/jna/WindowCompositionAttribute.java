package ru.krlvm.swingacrylic.jna;

public interface WindowCompositionAttribute {
    int WCA_ACCENT_POLICY = 19;
}